## microblog
An example web application for the book The New And Improved Flask Mega-Tutorial
